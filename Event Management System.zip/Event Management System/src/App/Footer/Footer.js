import React from "react";
import classNames from "./Footer.module.css";

export default function Footer() {
  return (
    <footer className={`${classNames.footer} card-footer`}>
      <p className='card-footer-item'>
      &#169;	copyright
      </p>
    </footer>
  );
}
