import React from "react";

export default function EventInfoTitle({ children }) {
  return <h2 className='title is-4'>{children}</h2>;
}
