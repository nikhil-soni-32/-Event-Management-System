import firebase from '../firebase';

var provider = new firebase.auth.GoogleAuthProvider();


export default provider;